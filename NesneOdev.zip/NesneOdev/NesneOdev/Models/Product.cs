﻿namespace NesneOdev.Models
{
    public class Product : BaseEntity
    {
        public string Name { get; set; } // Ürünün adı
        public decimal Price { get; set; } // Ürünün fiyatı
        public int Stock { get; set; } // Ürünün stoğu

        // Ürünün stok durumunu kontrol etmek için bir yardımcı özellik
        public bool IsInStock => Stock > 0;

        // Ürün fiyatını indirgeme işlevi eklemek için örnek bir metod
        public void ApplyDiscount(decimal discountPercentage)
        {
            if (discountPercentage > 0 && discountPercentage <= 100)
            {
                Price -= Price * discountPercentage / 100;
            }
        }

        // Ürünün fiyatının geçerli olup olmadığını kontrol eden bir metot (örneğin negatif fiyat kontrolü)
        public bool IsPriceValid()
        {
            return Price > 0;
        }
    }
}
