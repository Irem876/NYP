﻿namespace NesneOdev.Models
{
    public class Order : BaseEntity
    {
        public int ProductId { get; set; } // Sipariş edilen ürünün ID'si
        public int Quantity { get; set; } // Sipariş edilen ürünün miktarı
        public DateTime OrderDate { get; set; } // Sipariş tarihi

        // Navigation property (isteğe bağlı, ilişkileri göstermek için kullanılır)
        public Product Product { get; set; }

        // Siparişin toplam tutarını hesaplayan özellik
        public decimal TotalAmount
        {
            get
            {
                // Eğer Product nesnesi null değilse, toplam tutarı hesapla
                return Product != null ? Quantity * Product.Price : 0;
            }
        }
    }
}
