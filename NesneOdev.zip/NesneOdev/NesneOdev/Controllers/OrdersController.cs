﻿using Microsoft.AspNetCore.Mvc;
using NesneOdev.Models;
using NesneOdev.Repositories;

[Route("api/[controller]")]
[ApiController]
public class OrdersController : ControllerBase
{
    private readonly IOrderRepository _orderRepository;

    public OrdersController(IOrderRepository orderRepository)
    {
        _orderRepository = orderRepository;
    }

    [HttpGet]
    public async Task<ActionResult<List<Order>>> GetAllOrders()
    {
        var orders = await _orderRepository.GetAllAsync();
        return Ok(orders);
    }

    [HttpGet("{id}")]
    public async Task<ActionResult<Order>> GetOrderById(int id)
    {
        var order = await _orderRepository.GetByIdAsync(id);
        if (order == null)
        {
            return NotFound();
        }
        return Ok(order);
    }

    [HttpPost]
    public async Task<ActionResult> AddOrder([FromBody] Order order)
    {
        if (order == null)
        {
            return BadRequest("Order is null");
        }

        await _orderRepository.AddAsync(order);
        return CreatedAtAction(nameof(GetOrderById), new { id = order.Id }, order);
    }

    [HttpGet("total")]
    public async Task<ActionResult<decimal>> GetTotalOrderAmount()
    {
        var total = await _orderRepository.GetTotalAmountAsync();
        return Ok(total);
    }
}
