﻿using System.IO;

namespace NesneOdev.Logging
{
    public class FileLogger : ILogger
    {
        private readonly string _filePath;

        public FileLogger(string filePath)
        {
            _filePath = filePath;
        }

        public void Log(string message)
        {
            // Dosyaya log yazma işlemi
            using (StreamWriter writer = new StreamWriter(_filePath, true))
            {
                writer.WriteLine($"[{DateTime.Now}] - {message}");
            }
        }
    }
}
