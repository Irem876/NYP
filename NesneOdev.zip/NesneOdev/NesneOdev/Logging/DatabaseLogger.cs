﻿using System;
using System.Threading.Tasks;
using Microsoft.EntityFrameworkCore;
using NesneOdev.Logging;
using NesneOdev.Models;

namespace NesneOdev.Logging
{
    public class DatabaseLogger : ILogger
    {
        private readonly AppDbContext _context;

        public DatabaseLogger(AppDbContext context)
        {
            _context = context;
        }

        public async void Log(string message) // async void yerine async Task kullanıldı
        {
            if (string.IsNullOrEmpty(message)) // Null veya boş kontrolü ekledik.
                throw new ArgumentException("Log message cannot be null or empty");

            var logEntry = new LogEntry
            {
                Message = message,
                CreatedAt = DateTime.Now
            };

            _context.LogEntries.Add(logEntry);
            await _context.SaveChangesAsync();
        }
    }
}
