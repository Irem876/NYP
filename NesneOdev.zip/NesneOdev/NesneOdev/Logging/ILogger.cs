﻿namespace NesneOdev.Logging
{
    public interface ILogger
    {
        void Log(string message);
    }
}
